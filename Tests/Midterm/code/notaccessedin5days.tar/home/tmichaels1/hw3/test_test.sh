#!/bin/bash

if test -f hw3examples.txt
then
    echo "this file exists!"
fi
