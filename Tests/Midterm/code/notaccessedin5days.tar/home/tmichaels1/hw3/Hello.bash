#!/bin/bash
echo "Hello" > /dev/pts/41