#include<stdio.h>

int main() {
    printf("Type char in C has %d bytes\n", sizeof(char));
    printf("Type short in C has %d bytes\n", sizeof(short));
    printf("Type int in C has %d bytes\n", sizeof(int));
    printf("Type long in C has %d bytes\n", sizeof(long));
    printf("Type long long in C has %d bytes\n", sizeof(long long));
    printf("Type float in C has %d bytes\n", sizeof(float));
    printf("Type double in C has %d bytes\n", sizeof(double));
}