#!/bin/bash

#make directories based on file extensions
mkdir -p others txt sh awk

#make copy of files
ls -l . | grep '^-' | awk '{ print "cp " $NF " " $NF "_copy"}' | sh 

#move files
ls . | grep '.txt_copy' | awk '{print "mv " $1 " txt"}' | sh
ls . | grep '.sh_copy' | awk '{print "mv " $1 " sh"}' | sh
ls . | grep '.awk_copy' | awk '{print "mv " $1 " awk"}' | sh
ls . | grep '_copy' | awk '{print "mv " $1 " others"}' | sh

#sorting files by month
ls -l txt | sort +5 -6 -M 
ls -l sh | sort +5 -6 -M 
ls -l awk | sort +5 -6 -M 
ls -l others | sort +5 -6 -M 

#compress directories sort and archive
tar -cf txt.tar txt
tar -cf sh.tar sh
tar -cf awk.tar awk
tar -cf others.tar others
tar -cf archived_directories.tar "$(ls *.tar | sort)"